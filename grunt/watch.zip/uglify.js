module.exports = {
    all: {
      files: [{
        expand: true,
        cwd: 'build/js/extended.js',
        src: '**/*.js',
        dest: 'build/js',
        ext: '.js'
}]
    }
  }
