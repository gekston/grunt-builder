module.exports = {
    all: [
        "build/"
    ]
};
