module.exports = {
    // options
    options: {
        limit: 3
    },

    creation: [
        'clean',
        'copy'
    ],
    concatJs: [
        'uglify'
    ],
    concatCss: [
        'clean',
        'jshint'
    ],
    mathjax: [
        'unzip'
    ],
    imgFirst: [
        'imagemin'
    ]
};
